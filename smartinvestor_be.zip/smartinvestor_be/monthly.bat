@echo off
echo Hello, Trading & Fundamental Download Program!
PowerShell -ExecutionPolicy Bypass -Command "Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope Process"
cd "C:\Users\HANJ29\Development\"
call ".\vdev1\Scripts\activate"
cd ".\web\UAT\smartinvestor_be\"

python manage.py pulldata --freq=ME --batch=True --dtype=trading
REM --resume="300145.SZ"

python manage.py pulldata --freq=ME --batch=True --dtype=fundamental

echo Hello, Pull Trading & Fundamental dataset Completed!

python manage.py predict --freq=M
echo Hello, Predict dataset Completed!

python manage.py fetchcorp
echo Hello, Fetching corp info Completed!

echo Hello, Monthly Job Chain Completed!
pause