import datetime
import pandas as pd

from datastore.models import (
    Corporation,
    CorporationBasic,
    StockCostHistory,
    StockFundamentalHistory,
    StockTradingHistory,
)
from django.conf import settings
from django.db.models import Q, Max
from prediction.models import StockCombinedFeature, StockPrediction
from rest_framework.decorators import api_view
from rest_framework.response import Response
from datastore.utils.tushare_util import fetch_tushare_data
from prediction.utils.ta_util import calculate_atr
from utils.analysis_utils import is_last_row_value_below_quantile
from users.models import User, UserWatchlist
from prediction.models import StockGainLossQuantile
from pandas.tseries.offsets import BDay
from users.models import UserStockTag
import time


# Create your views here.
@api_view(["GET"])
def get_stock_trading_history(request, ts_code, freq, adj="qfq", count=None):
    # Dummy response, replace with actual logic
    try:
        # Get the latest N working days (trading days) up to today
        count = int(count) if count is not None else settings.DEFAULT_HISTORY_COUNT
        all_dates = (
            StockTradingHistory.objects.filter(ts_code=ts_code, freq=freq)
            .order_by("-trade_date")
            .values_list("trade_date", flat=True)
            .distinct()
        )
        latest_dates = list(all_dates[:count])
        if not latest_dates:
            records = []
        else:
            records = StockTradingHistory.objects.filter(
                ts_code=ts_code, freq=freq, trade_date__in=latest_dates
            ).order_by("trade_date")

        # records = records.order_by("trade_date")
        adj = (adj or "qfq").lower()
        field_map = {
            "qfq": (
                "open_qfq",
                "high_qfq",
                "low_qfq",
                "close_qfq",
                "vol",
                "amount",
                "pct_change",
            ),
            "hfq": (
                "open_hfq",
                "high_hfq",
                "low_hfq",
                "close_hfq",
                "vol",
                "amount",
                "pct_change",
            ),
            "bfq": ("open", "high", "low", "close", "vol", "amount", "pct_change"),
        }

        df = pd.DataFrame([r.__dict__ for r in records])
        df = calculate_atr(
            df=df,
            period=20,
            high_col="high_qfq",
            low_col="low_qfq",
            close_col="close_qfq",
        )
        for idx, r in enumerate(records):
            atr = df.at[idx, "atr"] if "atr" in df.columns and idx < len(df) else None
            close_qfq = (
                df.at[idx, "close_qfq"]
                if "close_qfq" in df.columns and idx < len(df)
                else None
            )
            if atr is not None and pd.notnull(atr) and close_qfq is not None:
                atr = round(atr, 2)
                setattr(r, "stoploss_1", close_qfq - atr)
                setattr(r, "stoploss_2", close_qfq - 2 * atr)
                setattr(r, "takeprofit_1", close_qfq + atr)
                setattr(r, "takeprofit_2", close_qfq + 2 * atr)
            else:
                setattr(r, "stoploss_1", None)
                setattr(r, "stoploss_2", None)
                setattr(r, "takeprofit_1", None)
                setattr(r, "takeprofit_2", None)

        def get_indicator_value(record):
            indicator_fields = {
                "macd": ["macd", "macd_dif", "macd_dea"],
                "rsi": ["rsi_6", "rsi_12", "rsi_24"],
                "kdj": ["kdj_k", "kdj_d", "kdj_j"],
                "boll": ["boll_mid", "boll_upper", "boll_lower"],
                "cci": ["cci"],
                # Add more indicators here as needed
            }
            indicator_values = {}
            for ind_name, fields in indicator_fields.items():
                indicator_values[ind_name] = {
                    f: getattr(record, f, None) for f in fields
                }
            return indicator_values

        fields = field_map.get(adj, field_map["qfq"])
        data = [
            {
                "ts_code": r.ts_code,
                "trade_date": r.trade_date,
                "open": getattr(r, fields[0], None),
                "high": getattr(r, fields[1], None),
                "low": getattr(r, fields[2], None),
                "close": getattr(r, fields[3], None),
                "sl1": getattr(r, "stoploss_1", None),
                "sl2": getattr(r, "stoploss_2", None),
                "tp1": getattr(r, "takeprofit_1", None),
                "tp2": getattr(r, "takeprofit_2", None),
                "vol": getattr(r, fields[4], None),
                "amount": getattr(r, fields[5], None),
                "pct_chg": getattr(r, fields[6], None),
                "freq": r.freq,
                "indicator": get_indicator_value(r),
            }
            for r in records
        ]

        if not data:
            return Response(
                {"error": "No trading history found for given ts_code and freq."},
                status=404,
            )
        return Response({"data": data, "ts_code": ts_code, "freq": freq})
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_stock_fundamental_history(request, ts_code, freq, count):
    # Dummy response, replace with actual logic
    try:
        # Get the latest N working days (trading days) up to today
        count = int(count) if count is not None else settings.DEFAULT_HISTORY_COUNT
        all_dates = (
            StockFundamentalHistory.objects.filter(ts_code=ts_code, freq=freq)
            .order_by("-trade_date")
            .values_list("trade_date", flat=True)
            .distinct()
        )
        latest_dates = list(all_dates[:count])
        if not latest_dates:
            records = []
        else:
            records = StockFundamentalHistory.objects.filter(
                ts_code=ts_code, freq=freq, trade_date__in=latest_dates
            ).order_by("trade_date")
        data = [{**r.to_dict()} for r in records]
        if not data:
            return Response(
                {"error": "No fundamental history found for given ts_code and freq."},
                status=404,
            )
        return Response({"data": data, "ts_code": ts_code, "freq": freq})
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_stock_corporation(request, input_text):
    # Dummy response, replace with actual logic
    try:
        # Perform a fuzzy search on multiple fields
        user = request.user if request.user.is_authenticated else User.get_admin_user()
        # Fuzzy search by text
        corp_q = (
            Q(ts_code__icontains=input_text)
            | Q(name__icontains=input_text)
            | Q(fullname__icontains=input_text)
            | Q(enname__icontains=input_text)
            | Q(cnspell__icontains=input_text)
        )
        corp_list = list(Corporation.objects.filter(corp_q)[:10])
        # Add corporations by tag
        tag_corp_ids = set(
            UserStockTag.objects.filter(
                user=user, tag__icontains=input_text, is_enabled=True
            ).values_list("corporation", flat=True)
        )
        for corp in Corporation.objects.filter(id__in=tag_corp_ids):
            if corp not in corp_list:
                corp_list.append(corp)
        # Attach tags
        tags_map = {}
        for tag in UserStockTag.objects.filter(
            user=user, corporation__in=corp_list, is_enabled=True
        ):
            tags_map.setdefault(tag.corporation.ts_code, []).append(tag.tag)
        data = [
            {
                "ts_code": corp.ts_code,
                "name": corp.name,
                "fullname": corp.fullname,
                "enname": corp.enname,
                "listdate": corp.list_date,
                "cnspell": corp.cnspell,
                "tags": tags_map.get(corp.ts_code, []),
            }
            for corp in corp_list
        ]
        if not data:
            return Response({"error": "No matching corporations found."}, status=404)

        return Response({"data": data, "input_text": input_text}, status=200)
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_watch_list(request, from_index, to_index):
    # Dummy response, replace with actual logic
    try:
        user = request.user if request.user.is_authenticated else User.get_admin_user()
        if not user:
            return Response({"error": "Authentication required."}, status=401)
        market = request.query_params.get("market", "6")
        from_index = int(from_index)
        to_index = int(to_index)
        if market == "HO":
            queryset = UserWatchlist.objects.filter(
                user=user, is_enabled=True, hold_a_position=True
            ).order_by("ts_code")
        else:
            queryset = UserWatchlist.objects.filter(
                user=user, is_enabled=True, ts_code__startswith=market
            ).order_by("ts_code")
        total = queryset.count()
        records = queryset[from_index:to_index]
        data = []
        for item in records:
            item_dict = item.to_dict() if hasattr(item, "to_dict") else {}
            corp_basic = getattr(getattr(item, "corporation", None), "basic_info", None)
            try:
                if corp_basic and hasattr(corp_basic.get(), "to_dict_short"):
                    item_dict["basic_info"] = corp_basic.get().to_dict_short()
            except Exception:
                item_dict["basic_info"] = {}
            prediction = getattr(
                getattr(item, "corporation", None), "stock_predictions", None
            )
            if prediction:
                pred = prediction.order_by("-trade_date").first()
                if pred and hasattr(pred, "to_dict"):
                    item_dict["prediction"] = pred.to_dict()
            data.append(item_dict)
        return Response(
            {"data": data, "from": from_index, "to": to_index, "total": total}
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_stock_gain_loss_statistic(request, ts_code, freq, period):
    """
    Get stock gain/loss statistics for a specific stock.
    """
    try:
        records = StockGainLossQuantile.objects.filter(
            ts_code=ts_code, quantile=0.5, freq=freq, period=period
        ).order_by("-top_or_bottom")

        data = [
            {
                k: v
                for k, v in (
                    r.to_dict()
                    if hasattr(r, "to_dict")
                    else {
                        "top_or_bottom": getattr(r, "top_or_bottom", None),
                        "gain_loss": getattr(r, "gain_loss", None),
                        # Add other relevant fields as needed
                    }
                ).items()
                if k not in ["period", "ts_code", "quantile", "freq"]
            }
            for r in records
        ]
        if not data:
            return Response(
                {"error": "No gain/loss statistics found for given ts_code."},
                status=404,
            )
        return Response({"data": data, "ts_code": ts_code})
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_stock_list(request, from_index, to_index):
    # Dummy response, replace with actual logic
    try:
        from_index = int(from_index)
        to_index = int(to_index)
        queryset = Corporation.objects.all().order_by("ts_code")
        total = queryset.count()
        records = queryset[from_index:to_index]
        data = [
            {
                "ts_code": corp.ts_code,
                "name": corp.name,
                "fullname": corp.fullname,
                "enname": corp.enname,
                "listdate": corp.list_date,
                "cnspell": corp.cnspell,
            }
            for corp in records
        ]
        return Response(
            {"data": data, "from": from_index, "to": to_index, "total": total}
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_stock_basic(request, ts_code):
    # Dummy response, replace with actual logic
    try:
        corp_basic = CorporationBasic.objects.filter(ts_code=ts_code).first()
        if not corp_basic:
            return Response(
                {"error": "No basic information found for given ts_code."}, status=404
            )
        data = (
            corp_basic.to_dict()
            if hasattr(corp_basic, "to_dict")
            else {
                "ts_code": corp_basic.ts_code,
                "name": corp_basic.basic_info.name,
                "industry": getattr(corp_basic, "industry", None),
                "market": getattr(corp_basic, "market", None),
                "list_date": getattr(corp_basic, "list_date", None),
                # Add other fields as needed
            }
        )
        return Response({"data": data, "ts_code": ts_code})
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_stock_prediction_result(
    request, ts_code, model, volatility, period, freq, version
):
    # Dummy response, replace with actual logic
    try:
        filters = {}
        excludes = [
            "id",
            "created_at",
            "corporation",
            "freq",
            "applied_model",
            "model_version",
            "volatility",
        ]

        if ts_code:
            filters["ts_code"] = ts_code
        if model:
            filters["applied_model"] = model
        if volatility:
            filters["volatility"] = volatility
        if period:
            try:
                period_days = int(period)
                today = datetime.date.today()
                start_date = today - datetime.timedelta(days=period_days)
                filters["trade_date__gte"] = start_date
                filters["trade_date__lte"] = today
                del filters["prediction_date"]
            except Exception:
                pass
        if freq:
            filters["freq"] = freq
        if version:
            filters["model_version"] = version

        records = StockPrediction.objects.filter(
            **filters, top_or_bottom__in=["B", "T"]
        ).order_by("-trade_date")
        data = [
            {k: v for k, v in r.to_dict().items() if k not in excludes} for r in records
        ]
        if not data:
            return Response(
                {"error": "No prediction results found for given parameters."},
                status=404,
            )
        return Response({"data": data, **filters})
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_all_stocks_prediction_result(request):
    ts_code = request.GET.get("ts_code")
    model_name = request.GET.get("model_name")
    volatility = request.GET.get("volatility")
    trade_date = request.GET.get("trade_date")
    freq = request.GET.get("freq")
    from_index = int(request.GET.get("from", 0))
    to_index = int(request.GET.get("to", from_index + 50))

    try:
        filters = {}
        excludes = [
            "id",
            "created_at",
            "corporation",
            "freq",
            "applied_model",
            "model_version",
            "volatility",
        ]
        if ts_code:
            filters["ts_code"] = ts_code
        if model_name:
            filters["model_name"] = model_name
        if volatility:
            filters["volatility"] = volatility
        if trade_date:
            filters["prediction_date"] = trade_date
        if freq:
            filters["freq"] = freq

        queryset = StockPrediction.objects.filter(**filters).order_by("-trade_date")
        total_count = queryset.count()
        records = queryset[from_index:to_index]
        data = [
            {k: v for k, v in r.to_dict().items() if k not in excludes} for r in records
        ]
        if not data:
            return Response(
                {"error": "No prediction results found for given parameters."},
                status=404,
            )
        return Response(
            {
                "data": data,
                "from": from_index,
                "to": to_index,
                "total": total_count,
                **filters,
            }
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


from django.db.models import Value, CharField


@api_view(["GET"])
def pick_stocks_by_params(
    request,
    trade_date,
    scope,
    model,
    model_version,
    top_bottom,
    freq,
    period,
    params,
    from_index,
    to_index,
):
    try:
        # Step 1: Filter predictions according to scope
        if top_bottom == "B,T":
            prediction_qs = StockTradingHistory.objects.filter(
                trade_date=trade_date,
                freq=freq,
            ).values(
                "ts_code",
                "trade_date",
                top_or_bottom=Value("", output_field=CharField()),
            )

        else:
            prediction_qs = StockPrediction.objects.filter(
                trade_date=trade_date,
                applied_model=model,
                model_version=model_version,
                freq=freq,
                top_or_bottom__in=[top_bottom],
            )
        if not prediction_qs.exists():
            return Response(
                {
                    "data": [],
                    "trade_date": trade_date,
                    "model_name": model,
                    "freq": freq,
                    "params": params,
                },
                status=200,
            )
        if scope.isdigit():
            prediction_qs = prediction_qs.filter(ts_code__startswith=scope)
        elif scope == "WATCHLIST":
            hold_codes = list(
                UserWatchlist.objects.filter(is_enabled=True).values_list(
                    "ts_code", flat=True
                )
            )
            prediction_qs = prediction_qs.filter(ts_code__in=hold_codes)
        screened_stocks = list(prediction_qs.values_list("ts_code", "top_or_bottom"))

        param_list = [p for p in params.split("|") if p.strip()]
        freq_days_map = {"D": 1, "W": 7, "M": 30}
        base_days = freq_days_map.get(freq, 1)
        period_days = base_days * int(period) if period else base_days
        end_date = datetime.datetime.strptime(trade_date, "%Y-%m-%d").date()
        start_date = end_date - datetime.timedelta(days=period_days - 1)

        ts_codes = [ts_code for ts_code, _ in screened_stocks]
        (
            trading_fields,
            fundamental_fields,
            feature_fields,
            feature_diff_fields,
            stat_params,
            feature_params,
            feature_diff_params,
        ) = (
            set(),
            set(),
            set(),
            set(),
            [],
            [],
            [],
        )
        for param in param_list:
            key_param = param.split(":")
            if len(key_param) < 2:
                continue
            field_name = key_param[1][1:].lower()
            if key_param[1].startswith("T"):
                trading_fields.add(field_name)
            elif key_param[1].startswith("F"):
                fundamental_fields.add(field_name)
            if key_param[0] == "STAT":
                stat_params.append((key_param[0], key_param[1], field_name))
            if key_param[0] == "COST":
                winner_rate = int(key_param[1])
                cost_qs = StockCostHistory.objects.filter(
                    ts_code__in=ts_codes,
                    winner_rate__gte=winner_rate,
                    trade_date__gte=start_date.strftime("%Y-%m-%d"),
                    trade_date=trade_date,
                )
                ts_codes = list(cost_qs.values_list("ts_code", flat=True))
                stat_params.append((key_param[0], key_param[1], key_param[1]))
            if key_param[0] == "FEAT":
                feature_param = key_param[1]
                feature_fields.add(feature_param.lower())
                feature_params.append(feature_param.lower())
        
        diff_param = params.split(":")
        chg_pct = None     
        if diff_param[0] == "FEAT_DIFF":
            parts = diff_param[1].split("|")
            if len(parts) >= 4:
                chg_pct = float(parts[-1])
                period = parts[-2] if len(parts) >= 2 else None
                for raw_field in parts[:2]:
                    field_name = f"{raw_field.replace('X', period)}_DIFF".lower()
                    feature_diff_fields.add(field_name)
                    feature_diff_params.append(field_name)
                

        def fetch_data(model_cls, ts_code, freq, start_date, end_date, fields):
            if not fields:
                return []
            qs = model_cls.objects.filter(
                ts_code=ts_code,
                freq=freq,
                trade_date__gte=start_date.strftime("%Y-%m-%d"),
                trade_date__lte=end_date.strftime("%Y-%m-%d"),
            ).values("ts_code", "trade_date", *fields)
            return list(qs)

        def get_latest_record(model_cls, ts_code, freq, end_date):
            latest_date = model_cls.objects.filter(
                ts_code=ts_code,
                freq=freq,
                trade_date__lte=end_date.strftime("%Y-%m-%d"),
            ).aggregate(latest_date=Max("trade_date"))["latest_date"]
            if latest_date:
                rec = model_cls.objects.filter(
                    ts_code=ts_code, freq=freq, trade_date=latest_date
                ).first()
                return rec.to_dict() if rec and hasattr(rec, "to_dict") else {}
            return {}

        result = []
        count = 0
        for ts_code, top_or_bottom in screened_stocks:
            if ts_code not in ts_codes or count >= to_index:
                continue
            passed = True
            quantile_value = None
            for filter_type, param_type, field_name in stat_params:
                df = pd.DataFrame()
                if filter_type == "STAT":
                    if param_type.startswith("T"):
                        df = pd.DataFrame(
                            fetch_data(
                                StockTradingHistory,
                                ts_code,
                                freq,
                                start_date,
                                end_date,
                                trading_fields,
                            )
                        )
                    elif param_type.startswith("F"):
                        df = pd.DataFrame(
                            fetch_data(
                                StockFundamentalHistory,
                                ts_code,
                                freq,
                                start_date,
                                end_date,
                                fundamental_fields,
                            )
                        )
                    if not df.empty:
                        result_value, _, quantile_value = (
                            is_last_row_value_below_quantile(
                                df, field_name, quantile=0.1
                            )
                        )
                        if not result_value:
                            passed = False
                            break

            for filter_type in feature_params:
                df = pd.DataFrame(
                    fetch_data(
                        StockCombinedFeature,
                        ts_code,
                        freq,
                        end_date,
                        end_date,
                        feature_fields,
                    )
                )
                if not df.empty:
                    for field in feature_fields:
                        if df[field].iloc[0] != "1":
                            passed = False
                            break
                        
            for filter_type in feature_diff_params: 
                df = pd.DataFrame(
                    fetch_data(
                        StockCombinedFeature,
                        ts_code,
                        freq,
                        end_date,
                        end_date,
                        feature_diff_fields,
                    )
                )  
                
                if not df.empty:
                    # close price in low price
                    if df[feature_diff_params[0]].iloc[0] > 0.0:                            
                        passed = False
                        break
                    if df[feature_diff_params[1]].iloc[0] < chg_pct:
                        passed = False
                        break
                        
                        
            if passed:
                corp_obj = Corporation.objects.filter(ts_code=ts_code).first()
                corp_basic_obj = getattr(corp_obj, "basic_info", None)
                corp_basic = {}

                if corp_basic_obj and hasattr(corp_basic_obj, "first"):
                    basic = corp_basic_obj.first()
                    corp_basic = (
                        basic.to_dict_short()
                        if basic and hasattr(basic, "to_dict_short")
                        else {}
                    )
                latest_trading = get_latest_record(
                    StockTradingHistory, ts_code, freq, end_date
                )
                latest_fundamental = get_latest_record(
                    StockFundamentalHistory, ts_code, freq, end_date
                )
                result.append(
                    {
                        "ts_code": ts_code,
                        "name": getattr(corp_obj, "name", None),
                        "top_or_bottom": top_or_bottom,
                        **{
                            k: v
                            for k, v in (corp_basic or {}).items()
                            if k
                            not in [
                                "id",
                                "ts_code",
                                "trade_date",
                                "area",
                                "city",
                                "corporation",
                            ]
                        },
                        **latest_trading,
                        **latest_fundamental,
                        "quantile_param": (
                            round(quantile_value, 2)
                            if quantile_value is not None
                            else None
                        ),
                    }
                )
                count += 1

        paged_result = result[from_index:to_index]
        return Response(
            {
                "data": paged_result,
                "trade_date": trade_date,
                "model_name": model,
                "freq": freq,
                "params": params,
            }
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["POST"])
def add_stock_to_watchlist(request, ts_code):
    try:
        if not ts_code:
            return Response({"error": "ts_code is required."}, status=400)
        user = request.user if request.user.is_authenticated else User.get_admin_user()

        if not user:
            return Response({"error": "Authentication required."}, status=401)
        corporation = Corporation.objects.filter(ts_code=ts_code).first()
        watchlist_entry, created = UserWatchlist.objects.get_or_create(
            user=user,
            ts_code=ts_code,
            name=corporation.name,
            corporation=corporation,
            defaults={"is_enabled": True},
        )
        if not created and not watchlist_entry.is_enabled:
            watchlist_entry.is_enabled = True
            watchlist_entry.save()
        return Response({"message": "Stock added to watchlist.", "ts_code": ts_code})
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["PUT", "DELETE"])
def soft_delete_stock_from_watchlist(request, ts_code):
    try:
        if not ts_code:
            return Response({"error": "ts_code is required."}, status=400)
        user = request.user if request.user.is_authenticated else User.get_admin_user()

        if not user:
            return Response({"error": "Authentication required."}, status=401)
        result = UserWatchlist.disable_for_user_and_code(user, ts_code)
        if not result:
            return Response({"error": "Stock not found in watchlist."}, status=404)
        return Response(
            {"message": "Stock removed from watchlist.", "ts_code": ts_code}
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["POST"])
def mark_stock_as_hold(request, ts_code):
    try:
        user = request.user if request.user.is_authenticated else User.get_admin_user()

        if not ts_code:
            return Response({"error": "ts_code is required."}, status=400)
        if not user:
            return Response({"error": "Authentication required."}, status=401)
        # 默认将股票添加到自选股列表（如果不在的话）
        watchlist_entry, created = UserWatchlist.objects.get_or_create(
            user=user, ts_code=ts_code, defaults={"is_enabled": True}
        )
        if not watchlist_entry.is_enabled:
            watchlist_entry.is_enabled = True
            watchlist_entry.save()
        result = UserWatchlist.set_stock_as_hold(user, ts_code)
        if not result:
            return Response({"error": "Failed to mark stock as hold."}, status=400)
        in_watchlist = True  # Since we just marked it as hold, it's in the watchlist
        return Response(
            {
                "message": "Stock marked as hold.",
                "ts_code": ts_code,
                "in_watchlist": in_watchlist,
            }
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["PUT", "DELETE"])
def unmark_stock_as_hold(request, ts_code):
    try:
        user = request.user if request.user.is_authenticated else User.get_admin_user()

        if not ts_code:
            return Response({"error": "ts_code is required."}, status=400)
        if not user:
            return Response({"error": "Authentication required."}, status=401)
        updated = UserWatchlist.objects.filter(
            user=user, ts_code=ts_code, is_enabled=True
        ).update(hold_a_position=False)
        if not updated:
            return Response({"error": "Failed to unmark stock as hold."}, status=400)
        return Response(
            {
                "message": "Stock unmarked as hold.",
                "ts_code": ts_code,
                "in_watchlist": True,  # Still in watchlist since is_enabled=True
            }
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def check_watchlist_or_hold(request, ts_code):
    try:
        user = request.user if request.user.is_authenticated else User.get_admin_user()
        if not user:
            return Response({"error": "Authentication required."}, status=401)
        watchlist_entry = UserWatchlist.objects.filter(
            user=user, ts_code=ts_code, is_enabled=True
        ).first()
        in_watchlist = bool(watchlist_entry)
        hold_position = bool(watchlist_entry and watchlist_entry.hold_a_position)
        return Response(
            {
                "ts_code": ts_code,
                "in_watchlist": in_watchlist,
                "hold_position": hold_position,
            }
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_stock_tags(request, ts_code):
    try:
        user = request.user if request.user.is_authenticated else User.get_admin_user()
        if not user:
            return Response({"error": "Authentication required."}, status=401)
        tags = UserStockTag.objects.filter(user=user, ts_code=ts_code, is_enabled=True)
        tag_list = [tag.tag for tag in tags]
        return Response({"ts_code": ts_code, "tags": tag_list})
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["POST"])
def add_stock_tag(request, ts_code, tag):
    try:
        user = request.user if request.user.is_authenticated else User.get_admin_user()
        if not user:
            return Response({"error": "Authentication required."}, status=401)
        if not tag:
            return Response({"error": "Tag name is required."}, status=400)
        corporation = Corporation.objects.filter(ts_code=ts_code).first()
        tag_obj, created = UserStockTag.objects.get_or_create(
            user=user, ts_code=ts_code, corporation=corporation, tag=tag
        )
        if not created:
            return Response({"error": "Tag already exists."}, status=400)
        return Response(
            {"message": "Tag added successfully.", "ts_code": ts_code, "tag": tag}
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["DELETE"])
def delete_stock_tag(request, ts_code, tag):
    try:
        user = request.user if request.user.is_authenticated else User.get_admin_user()
        if not user:
            return Response({"error": "Authentication required."}, status=401)
        if not tag:
            return Response({"error": "Tag name is required."}, status=400)
        deleted = UserStockTag.objects.filter(
            user=user, ts_code=ts_code, tag=tag, is_enabled=True
        ).update(is_enabled=False)
        if not deleted:
            return Response({"error": "Tag not found."}, status=404)
        return Response(
            {
                "message": "Tag deleted successfully.",
                "ts_code": ts_code,
                "tag": tag,
            }
        )
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_stocks_with_same_tag(request, ts_code):
    try:
        user = request.user if request.user.is_authenticated else User.get_admin_user()
        if not user:
            return Response({"error": "Authentication required."}, status=401)
        # Find all tags for the given ts_code
        tags = UserStockTag.objects.filter(user=user, ts_code=ts_code, is_enabled=True)
        tag_names = [tag.tag for tag in tags]
        if not tag_names:
            return Response({"error": "No tags found for given ts_code."}, status=404)
        # Find all stocks with any of these tags for the user
        related_tags = UserStockTag.objects.filter(
            user=user, tag__in=tag_names, is_enabled=True
        ).exclude(ts_code=ts_code)
        stocks = []
        for tag_obj in related_tags:
            corp = tag_obj.corporation
            corp_basic = getattr(
                getattr(tag_obj, "corporation", None), "basic_info", None
            )
            stock_info = {
                "ts_code": corp.ts_code,
                "name": corp.name,
                # "fullname": corp.fullname,
                # "enname": corp.enname,
                # "listdate": corp.list_date,
                # "cnspell": corp.cnspell,
                # "tag": tag_obj.tag,
            }
            if corp_basic and hasattr(corp_basic.get(), "to_dict_short"):
                stock_info["basic_info"] = corp_basic.get().to_dict_short()
            stocks.append(stock_info)
        return Response({"data": stocks, "tags": tag_names, "ts_code": ts_code})
    except Exception as e:
        return Response({"error": str(e)}, status=500)


@api_view(["GET"])
def get_tushare_data(request, ts_code, data_type):
    try:
        # Call the Tushare API or your data fetching logic here
        df = fetch_tushare_data(ts_code, data_type)
        if df.empty:
            # Calculate previous workday's date
            prev_workday = datetime.date.today() - BDay(1)
            # Pass start/end date to fetch_tushare_data
            df = fetch_tushare_data(
                ts_code, data_type, start_date=prev_workday, end_date=prev_workday
            )
            if df.empty:
                return Response({"error": "No data found."}, status=404)
        # Define fields to include based on data_type
        fields_map = {
            "CYQ_PERF": [
                "ts_code",
                "trade_date",
                "his_low",
                "his_high",
                "cost_5pct",
                "cost_15pct",
                "cost_50pct",
                "cost_85pct",
                "cost_95pct",
                "weight_avg",
                "winner_rate",
            ],
            "INDICATOR": [
                "ts_code",
                "end_date",
                "eps",
                "total_revenue_ps",
                "revenue_ps",
                "undist_profit_ps",
                "gross_margin",
                # "inv_turn",
                "ar_turn",
                # "daa",
                "ebit",
                "ebitda",
                "fcff",
                "interestdebt",
                "netprofit_margin",
                "grossprofit_margin",
                "roe",
                "roe_dt",
                "debt_to_assets",
                "ca_to_assets",
                # "q_eps",
                "or_yoy",
                # "q_sales_yoy",
                # "q_sales_qoq",
                # "q_op_yoy",
                "q_op_qoq",
                "netprofit_yoy",
                "dt_netprofit_yoy",
            ],
            "PROFIT_FORECAST": [
                "ts_code",
                "trade_date",
                "report_date",
                "op_rt",
                "op_pr",
                "tp",
                "np",
                "eps",
                "pe",
                "rd",
                "roe",
                "ev_ebitda",
                "rating",
                "max_price",
                "min_price",
                "imp_dg",
            ],
            "FUND": [
                "ts_code",
                "end_date",
                "mkv",
                "amount",
                "stk_mkv_ratio",
                "stk_float_ratio",
            ],
            # Add more mappings as needed
        }
        # For INDICATOR type, scale specific fields
        if data_type == "INDICATOR" and not df.empty:
            for field in ["fcff", "gross_margin", "ebit", "ebitda", "interestdebt"]:
                if field in df.columns:
                    df[field] = df[field].apply(
                        lambda x: round(x / 1_000_000, 2) if pd.notnull(x) else x
                    )

        fields = fields_map.get(data_type, [])
        # Only keep the fields defined in fields_map for the given data_type
        df = df[fields] if fields and all(f in df.columns for f in fields) else df
        latest_rec = (
            df.iloc[0].replace({float("nan"): "n/a"}).to_dict() if not df.empty else {}
        )
        return Response({"data": latest_rec})
    except Exception as e:
        return Response({"error": str(e)}, status=500)
