import os
from datetime import date, timedelta
from django.conf import settings
import joblib
import pandas as pd
from datastore.models import (
    StockCostHistory,
    StockTradingHistory,
    StockFundamentalHistory,
)

from prediction.utils.ta_util import calculate_all_features
from prediction.models import StockPrediction
from prediction.models import StockCombinedFeature
from prediction.utils.feature_util import read_features_from_yaml

fields_ohlc = ["open_qfq", "high_qfq", "low_qfq", "close_qfq"]

fields_trading = [
    "change",
    "pct_change",
    "vol",
    "macd_dif",
    "macd_dea",
    "macd",
    "rsi_6",
    "rsi_12",
    "rsi_24",
    "kdj_k",
    "kdj_d",
    "kdj_j",
]

fields_fundamental = [
    "turnover_rate",
    "turnover_rate_f",
    "volume_ratio",
    "pb",
    "ps",
    "ps_ttm",
    "total_share",
    "float_share",
    "free_share",
    "total_mv",
    "circ_mv",
]

fields_cost = [
    "cost_pct5",
    "cost_pct15",
    "cost_pct50",
    "cost_pct85",
    "cost_pct95",
    "weight_avg",
    "winner_rate",
    "his_high",
    "his_low",
]

fields_calculated = [
    "atr",
    "pct_vol_chg",
    "pct_o2c",
    "lower_shadow",
    "upper_shadow",
    "mab_10",
    "mab_25",
    "volatility_ratio",
    "shadow_ratio",
    "mab_60",
    "mab_120",
    "mab_200",
    "free_share_ratio",
]

fields_calculated_M = [
    "atr",
    "pct_vol_chg",
    "pct_o2c",
    "lower_shadow",
    "upper_shadow",
    "mab_10",
    "mab_25",
    "volatility_ratio",
    "shadow_ratio",
    "mab_60",
]

features_DW = ["mab_60", "mab_120", "mab_200"]

features = [
    "trade_date",
    "change",
    "pct_chg",
    "vol",
    "atr",
    "pct_vol_chg",
    "pct_o2c",
    "lower_shadow",
    "upper_shadow",
    "dif",
    "dea",
    "bar",
    "rsi_6",
    "rsi_12",
    "rsi_24",
    "k",
    "d",
    "j",
    "turnover_rate",
    "turnover_rate_f",
    "volume_ratio",
    "pb",
    "ps",
    "ps_ttm",
    "total_share",
    "float_share",
    "free_share",
    "total_mv",
    "circ_mv",
    "free_share_ratio",
    "mab_10",
    "mab_25",
    "volatility_ratio",
    "shadow_ratio",
]


def predict_stock_trend(
    ts_code,
    corp,
    given_date,
    freq="D",
    model=None,
    model_name="XGB",
    volatility="STDOPT",
    version="1.1",
    project_root=None,
):
    """Predict stock trend using the specified model."""
    # 选择只包含在给定列表中的列
    # new_data_filtered = new_data[columns_to_keep if version in ["0.1"] else high_importance_features]

    # 获取最后一次预测的日期
    last_prediction = (
        StockPrediction.objects.filter(
            ts_code=ts_code,
            applied_model=model_name,
            volatility=volatility,
            freq=freq,
            model_version=version,
        )
        .order_by("-trade_date")
        .first()
    )

    if given_date is None:
        today = date.today()
        if freq == "D":
            next_date = (
                last_prediction.trade_date + timedelta(days=1)
                if last_prediction
                else today
            )
            while next_date.weekday() > 4:
                next_date += timedelta(days=1)

            given_date = next_date
        elif freq == "W":
            base_date = last_prediction.trade_date if last_prediction else today
            days_to_friday = (4 - base_date.weekday() + 7) % 7 or 7
            given_date = base_date + timedelta(days=days_to_friday)
        elif freq == "M":
            base_date = last_prediction.trade_date if last_prediction else today
            year, month = base_date.year, base_date.month
            month = month + 1 if month < 12 else 1
            year = year if month > 1 else year + 1
            first_next_month = date(year, month, 1)
            given_date = first_next_month + timedelta(days=32)
            given_date = date(given_date.year, given_date.month, 1) - timedelta(days=1)

        # Check if TradingHistory exists for next_date, else get latest available trade_date
        if not StockTradingHistory.objects.filter(
            ts_code=ts_code, freq=freq, trade_date=given_date
        ).exists():
            latest_record = (
                StockTradingHistory.objects.filter(ts_code=ts_code, freq=freq)
                .order_by("-trade_date")
                .first()
            )
            if latest_record:
                given_date = latest_record.trade_date
    feature_df = get_feature_data2(
        ts_code=ts_code,
        given_date=given_date,
        feature_list=None,
        freq=freq,
        project_root=project_root,
        model_name=model_name,
        version=version,
    )

    # 使用模型进行预测
    if feature_df is None or feature_df.empty:
        raise ValueError(f"No feature data available for {ts_code} on {given_date}")

    trade_dates = feature_df.pop("trade_date")
    feature_df = feature_df.apply(pd.to_numeric, errors="coerce")
    preds = model.predict(feature_df)
    proba = model.predict_proba(feature_df) if hasattr(model, "predict_proba") else None
    predictions = []
    for idx, pred in enumerate(preds):
        if pred in [1, 2]:
            label = {1: "B", 2: "T"}[pred]
            confidence = max(proba[idx]) if proba is not None else None
            predictions.append(
                {
                    "trade_date": trade_dates.iloc[idx],
                    "top_or_bottom": label,
                    "confidence": (
                        round(confidence, 2) if confidence is not None else None
                    ),
                }
            )

    save_prediction_result(
        ts_code=ts_code,
        corp=corp,
        # given_date=given_date,
        freq=freq,
        model_name=model_name,
        volatility=volatility,
        predictions=predictions,
        version=version,
    )
    return predictions


def save_prediction_result(
    ts_code,
    corp,
    freq="D",
    model_name="XGB",
    volatility="STDOPT",
    version="1.1",
    predictions=None,
):
    """
    Saves the prediction results into the StockPrediction table.

    Args:
        ts_code (str): Stock code.
        given_date (str): Date for which prediction is made.
        predictions (array-like): Prediction results.
        freq (str): Frequency, default 'D'.
    """
    records = []
    for record in predictions:
        record["freq"] = freq
        record["volatility"] = volatility
        record["applied_model"] = model_name
        record["model_version"] = version
        if "row" in record:
            del record["row"]
        records.append(record)

    for idx, pred in enumerate(records):
        StockPrediction.objects.create(
            ts_code=ts_code,
            freq=freq,
            trade_date=pred["trade_date"],
            corporation=corp,
            **{k: v for k, v in pred.items() if k != "trade_date" and k != "freq"},
        )


def get_model_by_name(
    model_name,
    volatility="STDOPT",
    freq="D",
    version="1.0",
    file_suffix="model",
    ts_code_prefix=None,
):
    """
    Constructs the file path for a model based on the given parameters.
    """
    # if model == "RF":
    models = {}
    if ts_code_prefix:
        models[ts_code_prefix] = load_model(
            f"{settings.STATIC_ROOT}/models/{version}/{model_name}_{volatility}_{freq}_{ts_code_prefix}.{file_suffix}"
        )

    for ts_code_prefix in ["60", "0", "3", "688"]:
        model_path = f"{settings.STATIC_ROOT}/models/{version}/{model_name}_{volatility}_{freq}_{ts_code_prefix}.{file_suffix}"
        if os.path.exists(model_path):
            models[ts_code_prefix] = load_model(model_path)
    return models


def load_model(model_path):
    """
    Loads a model from the specified file path.

    Args:
        model_path (str): Path to the model file.

    Returns:
        The loaded model object.
    """
    return joblib.load(model_path)


def get_ts_code_prefix(ts_code):
    if ts_code.startswith("60"):
        return "60"
    elif ts_code.startswith("0"):
        return "0"
    elif ts_code.startswith("3"):
        return "3"
    elif ts_code.startswith("688"):
        return "688"
    else:
        return ""


def get_feature_data2(
    ts_code,
    given_date,
    feature_list=None,
    freq="D",
    model_name="XGB",
    version="1.1",
    project_root=None,
):
    """
    Retrieves data from StockTradingHistory and StockFundamentalHistory for the given stock and feature list.

    Args:
        ts_code (str): Stock code to query.
        start_date (str): Start date (YYYY-MM-DD).
        end_date (str): End date (YYYY-MM-DD).
        feature_list (list, optional): List of feature names to retrieve. If None, uses default based on freq.
        freq (str): Frequency, 'D' for daily, 'W' for weekly, 'M' for monthly.
        model_name (str): Model name, default "XGB".
        version (str): Version, default "1.1".
        project_root (str): Project root directory.

    Returns:
        pd.DataFrame: DataFrame with columns matching feature_list.
    """
    if version == "1.1":
        return get_feature_data(
            ts_code,
            given_date,
            feature_list,
            freq,
        )
    else:
        ts_code_prefix = get_ts_code_prefix(ts_code)
        feature_type = f"{model_name}_{freq}_{ts_code_prefix}"
        feature_file_path = os.path.join(
            project_root, f"prediction/config/features/{version}/features.yaml"
        )

        if feature_list is None:
            # fields yaml定义了trading，fundamental，cost三种特征的字段
            feature_list = read_features_from_yaml(
                feature_file_path, feature_type=feature_type
            )
        qs = StockCombinedFeature.objects.filter(
            ts_code=ts_code, freq=freq, trade_date__gte=given_date
        ).values("trade_date", *(feature_list or []))
        df = pd.DataFrame(list(qs))
        return df


def get_feature_data(
    ts_code,
    given_date,
    feature_list=None,
    freq="D",
):
    """
    Retrieves data from StockTradingHistory and StockFundamentalHistory for the given stock and feature list.

    Args:
        ts_code (str): Stock code to query.
        start_date (str): Start date (YYYY-MM-DD).
        end_date (str): End date (YYYY-MM-DD).
        feature_list (list, optional): List of feature names to retrieve. If None, uses default based on freq.
        freq (str): Frequency, 'D' for daily, 'W' for weekly, 'M' for monthly.

    Returns:
        pd.DataFrame: DataFrame with columns matching feature_list.
    """

    # Select feature list based on freq
    calc_fields = []
    if freq in ["D", "W"]:
        calc_fields = fields_calculated
    elif freq == "M":
        calc_fields = fields_calculated_M

    if feature_list is not None:
        selected_features = feature_list
    else:
        selected_features = features if freq == "M" else features + features_DW

    # Validate input
    if not any([given_date]):
        raise ValueError("At least one of given_date must be provided.")

    # Build query params
    def get_qs(model, freq, fields):
        # Check if a record with the given date exists
        if not model.objects.filter(
            ts_code=ts_code, freq=freq, trade_date=given_date
        ).exists():
            raise ValueError(f"No data available for {ts_code} on {given_date}")

        if given_date:
            qs = (
                model.objects.filter(
                    ts_code=ts_code, freq=freq, trade_date__lte=given_date
                )
                .order_by("-trade_date")
                .values("trade_date", *fields)[:200]
            )
            today_str = date.today().strftime("%Y-%m-%d")
            if str(given_date) < today_str:
                extra_qs = (
                    model.objects.filter(
                        ts_code=ts_code,
                        freq=freq,
                        trade_date__gt=given_date,
                        trade_date__lte=today_str,
                    )
                    .order_by("-trade_date")
                    .values("trade_date", *fields)
                )
                qs = list(qs) + list(extra_qs)
            else:
                qs = list(qs)
            df = pd.DataFrame(qs)
            if not df.empty:
                df = df.sort_values(by="trade_date", ascending=False)
            return df
        return None

    trading_df = get_qs(StockTradingHistory, freq, fields=fields_trading + fields_ohlc)
    fundamental_df = get_qs(StockFundamentalHistory, freq, fields=fields_fundamental)
    # cost_df = get_qs(StockCostHistory, freq, fields=fields_cost)

    if (
        trading_df is None
        or trading_df.empty
        or fundamental_df is None
        or fundamental_df.empty
        # or cost_df is None
        # or cost_df.empty
    ):
        raise ValueError(f"No data available for {ts_code} on {given_date}")

    trading_df.rename(
        columns={
            "open_qfq": "open",
            "high_qfq": "high",
            "low_qfq": "low",
            "close_qfq": "close",
            "pct_change": "pct_chg",
            "macd_dif": "dif",
            "macd_dea": "dea",
            "macd": "bar",
            "kdj_k": "k",
            "kdj_d": "d",
            "kdj_j": "j",
        },
        inplace=True,
    )

    # Merge on date, prioritizing trading data, then fill with fundamental data
    # Merge trading and fundamental data on 'trade_date'
    result_df = trading_df.set_index("trade_date")
    if not fundamental_df.empty:
        fundamental_df = fundamental_df.set_index("trade_date")
        result_df = result_df.combine_first(fundamental_df)

    # Calculate additional features if needed
    if calc_fields:
        result_df = calculate_all_features(result_df)

    # Select and order columns
    result_df = result_df.reindex(columns=selected_features)

    # Reset index to make 'trade_date' a column
    result_df = result_df.reset_index()

    # Filter rows based on provided dates
    result_df["trade_date"] = result_df["trade_date"].astype(str)
    if given_date:
        result_df = result_df[result_df["trade_date"] >= str(given_date)]

    # else: keep all

    # Drop 'index' column if present, but keep 'trade_date'
    result_df = result_df.drop(columns=["index"], errors="ignore")
    return result_df
