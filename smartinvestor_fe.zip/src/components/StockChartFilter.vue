<template>
    <el-affix :offset="75">
        <el-card>
            <el-row :gutter="12">
                <el-col :span="7">

                    <el-row :gutter="8">
                        <el-col :span="24">
                            <el-row :gutter="8">
                                <el-col :span="16">
                                    <el-text type="primary" tag="b"><el-link
                                            :href="stockTradeStore.website.startsWith('http') ? stockTradeStore.website : 'https://' + stockTradeStore.website"
                                            target="_blank" type="primary" style="font-size: 14px;font-weight: bold;">{{
                                                stockTradeStore.name + ' | ' +
                                            stockTradeStore.tsCode }}
                                        </el-link></el-text>
                                </el-col>
                                <el-col :span="4">
                                    <el-check-tag :checked="isInWatchlist" @change="toggleWatchlistStatus"
                                        type="danger">
                                        <el-text size="small">自</el-text>
                                    </el-check-tag>
                                </el-col>
                                <el-col :span="4">
                                    <el-check-tag :checked="isHolding" @change="toggleHoldingStatus" type="primary">
                                        <el-text size="small">持</el-text>
                                    </el-check-tag>
                                </el-col>
                            </el-row>
                        </el-col>
                        <el-col :span="24">
                            <el-row :gutter="8">
                                <el-col v-for="(item, idx) in [
                                    { label: '收', value: stockTradeStore.close, type: 'info' },
                                    { label: '幅', value: `${stockTradeStore.pctChg.toFixed(2)}%`, type: stockTradeStore.pctChg >= 0 ? 'danger' : 'success' },
                                    // { label: '止', value: stockTradeStore.low, type: 'info' }
                                ]" :key="idx" :span="8">
                                    <div style="border-radius: 4px; text-align: left;">
                                        <el-text :type="item.type" tag="b" size="small">
                                            {{ item.label }}: {{ item.value }}<template v-if="item.extra"> {{
                                                item.extra
                                            }}</template>
                                        </el-text>
                                    </div>
                                </el-col>
                            </el-row>
                        </el-col>
                    </el-row>
                </el-col>
                <el-col :span="2">
                    <div class="grid-content ep-bg-purple-light" style="text-align: center;">
                        <el-switch v-model="switchTopBtm" class="ml-2" inline-prompt
                            style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949" active-text="顶底开"
                            inactive-text="顶底关" @change="onTopBtmChange" />
                    </div>
                </el-col>
                <el-col :span="5">
                    <div class="grid-content ep-bg-purple-light" style="text-align: center;">
                        <el-radio-group v-model="selectedModel" size="small" @change="onModelChange">
                            <el-radio-button label="rf">rf</el-radio-button>
                            <el-radio-button label="xgb">xgb</el-radio-button>
                            <el-radio-button label="cat">cat</el-radio-button>
                        </el-radio-group>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div class="grid-content ep-bg-purple-light" style="text-align: center;">
                        <el-radio-group v-model="selectedPeriod" size="small" @change="onPeriodChange">
                            <el-radio-button label="30">30d</el-radio-button>
                            <el-radio-button label="60">60d</el-radio-button>
                            <el-radio-button label="200">1y</el-radio-button>
                            <el-radio-button label="400">2y</el-radio-button>
                        </el-radio-group>
                    </div>
                </el-col>
                <el-col :span="4">
                    <div class="grid-content ep-bg-purple-light" style="text-align: center;">
                        <el-radio-group v-model="selectedFreq" size="small" @change="onFreqChange">
                            <el-radio-button label="D">日</el-radio-button>
                            <el-radio-button label="W">周</el-radio-button>
                            <el-radio-button label="M">月</el-radio-button>
                        </el-radio-group>
                    </div>
                </el-col>
            </el-row>
            <el-row :gutter="12">
                <el-col :span="3">
                    <el-input v-if="inputVisible" ref="InputRef" v-model="inputValue" class="w-20" size="small"
                        @keyup.enter="handleInputConfirm" @blur="handleInputConfirm" />
                    <el-button v-else class="button-new-tag" size="small" @click="showInput">
                        + 新标签
                    </el-button>
                </el-col>
                <el-col :span="21" style="text-align: left; font-size: x-small; color: gray;">
                    <el-tag v-for="tag in dynamicTags" :key="tag" closable :disable-transitions="false"
                        @close="handleClose(tag)">
                        {{ tag }}
                    </el-tag>
                </el-col>

            </el-row>
        </el-card>
    </el-affix>
</template>

<script setup lang="ts">
import { nextTick, ref } from 'vue';
// Element Plus
import type { InputInstance } from 'element-plus';
import { ElMessage, ElRow, ElCol, ElCard, ElSwitch, ElRadioGroup, ElRadioButton, ElText, ElAffix, ElCheckTag, ElButton, ElTag, ElInput, ElLink } from 'element-plus';
import { useStockTradeStore } from '../stores/stockTradeStore';
import { useStockChartFilterStore } from '../stores/stockChartFilterStore';
import axios from 'axios';
import { inject } from 'vue';

const stockTradeStore = useStockTradeStore();
const stockChartFilterStore = useStockChartFilterStore();

const switchTopBtm = ref(false);
const selectedModel = ref('xgb');
const selectedPeriod = ref('60');
const selectedFreq = ref('D');

const isHolding = ref(false);
const isInWatchlist = ref(false);

const inputValue = ref('')
const dynamicTags = ref<string[]>([])
const inputVisible = ref(false)
const InputRef = ref<InputInstance>()

const baseURL = inject('baseURL');

async function fetchStockStatus(tsCode: string) {
    try {
        const res = await axios.get(`${baseURL}/watchlist/check/${tsCode}/`);
        if (res.data) {
            isHolding.value = !!res.data.hold_position;
            isInWatchlist.value = !!res.data.in_watchlist;
        }
    } catch (error) {
        console.error('Failed to fetch stock status:', error);
    }
}

async function toggleWatchlistStatus(watchlist: boolean) {
    try {
        let res;
        if (watchlist) {
            const url = `${baseURL}/watchlist/add/${stockTradeStore.tsCode}/`;
            res = await axios.post(url);
        } else {
            const url = `${baseURL}/watchlist/delete/${stockTradeStore.tsCode}/`;
            res = await axios.put(url);
        }
        if (res.status === 200) {
            isInWatchlist.value = !isInWatchlist.value;
            ElMessage.success(isInWatchlist.value ? '已加入自选股' : '已移除自选股');
        }
    } catch (error) {
        console.error('Failed to toggle watchlist status:', error);
        ElMessage.error('操作失败，请稍后重试');
    }
}

async function toggleHoldingStatus(hold: boolean) {
    try {
        const url = hold
            ? `${baseURL}/watchlist/hold/${stockTradeStore.tsCode}/`
            : `${baseURL}/watchlist/unhold/${stockTradeStore.tsCode}/`;
        const method = hold ? 'post' : 'put';
        const res = await axios({ url, method });
        if (res.status === 200) {
            isHolding.value = hold;
            isInWatchlist.value = res.data.in_watchlist; // 持仓后自动加入自选股，否则移除
            ElMessage.success(isHolding.value ? '已标记为持仓' : '已取消持仓标记');
        }
    } catch (error) {
        console.error('Failed to toggle holding status:', error);
        ElMessage.error('操作失败，请稍后重试');
    }
}

async function fetchStockTags(tsCode: string) {
    try {
        const res = await axios.get(`${baseURL}/tags/${tsCode}/`);
        if (Array.isArray(res.data.tags)) {
            dynamicTags.value = res.data.tags;
        }
    } catch (error) {
        console.error('Failed to fetch stock tags:', error);
    }
}


async function addStockTag(tsCode: string, tag: string) {
    try {
        const url = `${baseURL}/tags/add/${tsCode}/${encodeURIComponent(tag)}/`;
        const res = await axios.post(url);
        if (res.status === 200) {
            dynamicTags.value.push(tag);
            ElMessage.success('已添加标签');
        }
    } catch (error) {
        console.error('Failed to add stock tag:', error);
        ElMessage.error('添加标签失败，可能标签已存在');
    }
}

async function deleteStockTag(tsCode: string, tag: string) {
    try {
        const url = `${baseURL}/tags/delete/${tsCode}/${encodeURIComponent(tag)}/`;
        const res = await axios.delete(url);
        if (res.status === 200) {
            dynamicTags.value = dynamicTags.value.filter((t) => t !== tag);
            // dynamicTags.value.splice(dynamicTags.value.indexOf(tag), 1);
            ElMessage.success('已删除标签');
        }
    } catch (error) {
        console.error('Failed to delete stock tag:', error);
        ElMessage.error('删除标签失败，请稍后重试');
    }
}


const handleClose = (tag: string) => {
    deleteStockTag(stockTradeStore.tsCode, tag);
}

const showInput = () => {
    inputVisible.value = true;
    nextTick(() => {
        InputRef.value!.input!.focus()
    })
}

const handleInputConfirm = () => {
    addStockTag(stockTradeStore.tsCode, inputValue.value);
    inputVisible.value = false
    inputValue.value = ''
}

const onModelChange = () => stockChartFilterStore.setModel(selectedModel.value);
const onTopBtmChange = () => stockChartFilterStore.setTopBottomSwitch(switchTopBtm.value);
const onPeriodChange = () => stockChartFilterStore.setPeriod(selectedPeriod.value);
const onFreqChange = () => stockChartFilterStore.setFreq(selectedFreq.value);

import { onMounted } from 'vue';

onMounted(() => {
    if (stockTradeStore.tsCode) {
        fetchStockStatus(stockTradeStore.tsCode);
        fetchStockTags(stockTradeStore.tsCode);
    }
});

import { watch } from 'vue';

watch(
    () => stockTradeStore.tsCode,
    (newTsCode) => {
        if (newTsCode) {
            fetchStockStatus(newTsCode);
            fetchStockTags(newTsCode);
        }
    }
);

defineOptions({
    name: 'StockChartFilter'
});
</script>

<style scoped></style>